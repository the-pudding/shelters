// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/* global d3 */

/* usage
	import loadData from './load-data'
	loadData().then(result => {

	}).catch(console.error)
*/
function loadJSON(file) {
  return new Promise(function (resolve, reject) {
    d3.json("assets/data/".concat(file)).then(function (result) {
      // clean here
      resolve(result);
    }).catch(reject);
  });
}

function loadCSV(file) {
  return new Promise(function (resolve, reject) {
    d3.csv("assets/data/".concat(file)).then(function (result) {
      resolve(result);
    }).catch(reject);
  });
}

function loadExamples() {
  loadJSON('exampleDogs.json');
}

function loadExported() {
  loadCSV('exportedDogs.csv');
}

function loadAny(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("assets/data/".concat(file)).then(resolve).catch(reject);else if (ext === 'json') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadMap() {
  var loads = [loadCSV('loc_centers.csv'), loadCSV('movement_paths.csv'), loadJSON('topo.json')];
  return Promise.all(loads);
}

function loadCrosswalk() {
  var loads = [loadJSON('breed-crosswalk.json')];
  return Promise.all(loads);
}

var _default = {
  loadCSV: loadCSV,
  loadJSON: loadJSON,
  loadMap: loadMap,
  loadCrosswalk: loadCrosswalk,
  loadAny: loadAny // export default function loadData() {
  //   const loads = [loadJSON('exampleDogs.json'), loadCSV('exportedDogs.csv')];
  //   return Promise.all(loads);
  // }

};
exports.default = _default;
},{}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// reader parameters
var readerState = null; // updating text selections

var $section = d3.selectAll('.intro');
var $state = d3.selectAll('.userState');
var $name = $section.selectAll('.exampleDog');
var $pOut = $section.selectAll('.intro-dog_out');
var $pIn = $section.selectAll('.intro-dog_in');
var $pInEx = $section.selectAll('.intro-dog_inEx');
var $img = $section.selectAll('.intro-dog_image');
var $inCount = $section.selectAll('.inTotal');
var $outCount = $section.selectAll('.outTotal');
var $total = $section.selectAll('.stateTotal');
var $pupHerHis = $section.selectAll('.herhis');
var $pupSheHe = $section.selectAll('.shehe');
var $reason = $section.selectAll('.moveCondition');
var $dogOrigin = $section.selectAll('.dogOrigin');
var $stackBarContainer = $section.select('.intro-dog__bar');
var $exportedSection = d3.selectAll('.exported');
var $introAll = $section.selectAll('.prose-intro');
var $introDogCont = $section.select('.intro-dog');
var $postIntroIn = $exportedSection.select('.prose-block-in');
var $postIntroOut = $exportedSection.select('.prose-block-out');
var $postIntroOutEx = $exportedSection.select('.prose-block-outEx'); // constants

var exampleDogs = null;
var exportedDogs = null;
var readerDog = null;
var importExport = null;
var readerStateData = null;
var formatCount = d3.format(',.0f');
var formatPercent = d3.format('.0%');

function updateLocation(loc) {
  readerState = loc;
  filterDogs();
}

function cleanData(arr) {
  return arr.map(function (d, i) {
    return _objectSpread({}, d, {
      imported: d.imported === 'TRUE'
    });
  });
}

function updateBars(state) {
  var selState = state;
  var perOut = +selState.imported / +selState.total;
  var perIn = (+selState.total - +selState.imported) / +selState.total;
  $stackBarContainer.select('.bar__inState').style('flex', "".concat(perIn, " 1 0"));
  $stackBarContainer.select('.bar__outState').style('flex', "".concat(perOut, " 1 0"));
  $stackBarContainer.select('.bar__inState-label').text(perOut < 0.01 ? '> 99%' : formatPercent(perIn));
  $stackBarContainer.select('.bar__outState-label').text(perOut < .01 ? '< 1%' : formatPercent(perOut));
  $section.select('.inPer').text(perOut < .01 ? '< 1%' : formatPercent(perOut));
  var oneHundred = perOut === 0 || perIn === 0;
  $stackBarContainer.classed('is-hidden', oneHundred);
}

function filterDogs() {
  readerDog = exampleDogs.filter(function (d) {
    return d.current === readerState;
  });
  readerStateData = importExport.filter(function (d) {
    return d.location === readerState;
  })[0]; // update state

  $state.text(readerState);
  $name.text(readerDog[0].name); // show appropriate text

  var exampleImport = +readerDog[0].imported;
  var exportFew = +readerStateData.exported <= 1;

  if (exampleImport) {
    $pOut.classed('is-visible', true);
    $pIn.classed('is-visible', false);
    $pInEx.classed('is-visible', false); // $exportedSection.classed('is-hidden', false)

    $postIntroIn.classed('is-hidden', false);
    $postIntroOut.classed('is-hidden', true);
    $postIntroOutEx.classed('is-hidden', true);
  } else if (!exampleImport) {
    $pOut.classed('is-visible', false);
    $postIntroIn.classed('is-hidden', true);

    if (readerStateData.exported <= 1) {
      $pInEx.classed('is-visible', false);
      $pIn.classed('is-visible', true);
      $postIntroOut.classed('is-hidden', false);
      $postIntroOutEx.classed('is-hidden', true); // $exportedSection.classed('is-hidden', true)
    } else {
      $pInEx.classed('is-visible', true);
      $pIn.classed('is-visible', false); // $exportedSection.classed('is-hidden', false)

      $postIntroOut.classed('is-hidden', true);
      $postIntroOutEx.classed('is-hidden', false);
    }
  } // update counts


  if (readerStateData) {
    $inCount.text(formatCount(+readerStateData.imported));
    $outCount.text(formatCount(+readerStateData.exported));
    $total.text(formatCount(+readerStateData.total));
  } // update pronouns


  var pupPronoun = readerDog[0].sex;
  $pupHerHis.text(pupPronoun === 'M' ? 'his' : 'her');
  $pupSheHe.text(pupPronoun === 'M' ? 'he' : 'she'); // update conditions

  $reason.text(readerDog[0].conditions);
  $dogOrigin.text(readerDog[0].original); // add dog image

  var fileName = readerDog[0].name.replace(' ', '');
  var fileState = readerDog[0].current.replace(' ', '_');
  $img.attr('src', "assets/images/faces/".concat(fileState, ".png"));
  updateBars(readerStateData);
} // code for determining user's location and subsequent data


function resize() {}

function init(loc) {
  return new Promise(function (resolve, reject) {
    var files = ['exampleDogs.json', 'importExport.csv'];
    var loads = files.map(_loadData.default.loadAny);
    Promise.all(loads).then(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
          exampleDogsData = _ref2[0],
          importExportData = _ref2[1];

      exampleDogs = cleanData(exampleDogsData);
      importExport = importExportData;
      readerState = loc;
      resolve();
    }).then(filterDogs).catch(console.error);
  });
}

var _default = {
  init: init,
  resize: resize,
  updateLocation: updateLocation
};
exports.default = _default;
},{"./load-data":"xZJw"}],"HYmN":[function(require,module,exports) {
"use strict";

var _loadData = _interopRequireDefault(require("./../load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.exportsByState = function init(options) {
  function createChart(el) {
    var $container = d3.select('.exported');
    var $sel = d3.select(el);

    var _data = $sel.datum(); // dimension stuff


    var width = 0;
    var height = 0;
    var marginTop = 0;
    var marginBottom = 0;
    var marginLeft = 0;
    var marginRight = 0; // scales

    var scaleX = null;
    var scaleY = null; // dom elements

    var $svg = null;
    var $axis = null;
    var $vis = null;
    var $containerMini = null;
    var $tooltip = $container.select('.exported-tooltip');
    var $stateTitle = null;
    var allDogs = null;
    var crosswalk = null;

    function handleMouseover() {
      // select hovered animal, its data, and the parent state/country div
      var hovered = d3.select(this);
      var hoveredData = hovered.data()[0];
      var parent = hovered.node().parentNode;
      var $selParent = d3.select(parent); // dim everyone except hovered dog

      var dogs = $selParent.selectAll('.dog').classed('dimmed', true);
      hovered.classed('dimmed', false); // update tooltip info based on hovered dog

      $tooltip.select('.tooltip-name').text(hoveredData.name);
      $tooltip.select('.tooltip-desc').text("".concat(hoveredData.age, " \u2022 ").concat(hoveredData.sex));
      $tooltip.select('.tooltip-breed').text(hoveredData.breed_secondary ? "".concat(hoveredData.breed_primary, " / ").concat(hoveredData.breed_secondary, " mix") : "".concat(hoveredData.breed_primary)); // update tooltip location based on mouse location

      var mouseX = d3.event.pageX; // const mouseY = d3.event.pageY
      // const toolTipHeight = $tooltip.node().offsetHeight;

      var toolTipWidth = $tooltip.node().offsetWidth;
      $tooltip.style('left', function () {
        var xMove = mouseX;
        if (mouseX > 0.5 * width) xMove -= toolTipWidth;
        console.log({
          xMove: xMove,
          width: width
        });
        return "".concat(xMove, "px");
      }).style('top', "".concat(d3.event.pageY, "px")).classed('is-hidden', false);
    }

    function handleMouseout() {
      var section = d3.select(this);
      d3.selectAll('.dog').classed('dimmed', false);
      $tooltip.classed('is-hidden', true);
    }

    function importCrosswalk() {
      _loadData.default.loadCrosswalk().then(function (result) {
        crosswalk = d3.map(result[0], function (d) {
          return d.file;
        });
      }).catch(console.error);
    }

    var Chart = {
      // called once at start
      init: function init() {
        importCrosswalk();
        Chart.resize();
        Chart.render();
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        width = $sel.node().offsetWidth - marginLeft - marginRight; // height = $sel.node().offsetHeight - marginTop - marginBottom;
        // $svg
        // 	.attr('width', width + marginLeft + marginRight)
        // 	.attr('height', height + marginTop + marginBottom);

        return Chart;
      },
      // update scales and render chart
      render: function render() {
        var $state = $sel.selectAll('.state').data(_data, function (d) {
          return "".concat(d.key, "-").concat(d.values.length);
        }).join(function (enter) {
          var state = enter.append('div').attr('class', 'state');
          $stateTitle = state.append('p').attr('class', 'state-name');
          var $container = state.append('div').attr('class', 'container-mini');
          return state; // .enter()
          // .append('div')
          // .attr('class', 'dog')
          //
        });
        $stateTitle.text(function (d) {
          return "".concat(d.key, " \u2022 ").concat(d.values.length);
        });
        $state.select('.container-mini').selectAll('.dog').data(function (d) {
          return d.values.sort(function (a, b) {
            return d3.ascending(a.file, b.file);
          });
        }).join(function (enter) {
          allDogs = enter.append('div').attr('class', 'dog').classed('highlighted', function (d) {
            return d.highlighted;
          }).on('mouseover', handleMouseover).on('mouseout', handleMouseout);
          return allDogs;
        }).style('background-image', function (d) {
          return d.file === 'mix' ? 'url(assets/images/profiles/labrador.png)' : "url(assets/images/profiles/".concat(d.file, ".png)");
        }); //
        // const sorted = data.values
        // 	.sort((a, b) => d3.ascending(a.size, b.size))
        // 	.sort((a,b) => {
        // 		return d3.ascending(a.file, b.file)
        // 	})
        // $containerMini.selectAll('.dog')
        // 	.data(sorted)
        // 	.join(
        // 		enter => {
        // 			enter.append('div')
        // 				.attr('class', 'dog')
        // 				.style('background-image', d => `url(assets/images/profiles/${d.file}.png)`)
        // 		},
        // 		exit => {
        // 			exit.remove()
        // 		}
        // 	)

        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $sel.datum(_data);
        Chart.render();
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{"./../load-data":"xZJw"}],"sOMx":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/exports-template");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// reader parameters
var readerState = null;
var lastReaderState = null;
var selToggle = 'exports'; // updating text selections

var $section = d3.selectAll('.exported');
var $container = $section.selectAll('.figure-container');
var $moreButton = $section.select('.show-more');
var $transparency = $section.select('.transparency');
var $toggle = $section.select('.conditionSelect');
var $warning = $section.select('.figure-warning'); // constants

var exampleDogs = null;
var exportedDogs = null;
var charts = null;
var importCount = 0;
var exportCount = 0;

function setupExpand() {
  $moreButton.on('click', function () {
    // was the container clipped before clicking?
    var expanded = !$container.classed('is-clipped');
    var text = !expanded ? 'Show Fewer' : 'Show All';
    $moreButton.text(text);
    $container.classed('is-clipped', expanded);

    if (expanded) {
      var y = +$moreButton.attr('data-y');
      window.scrollTo(0, y);
    }

    $moreButton.attr('data-y', window.scrollY);
    $transparency.classed('is-visible', expanded);
  });
}

function setupToggle() {
  $toggle.on('change', function (d) {
    var el = d3.select(this).node().value;
    selToggle = el; // update graphic

    updateLocation(readerState);
  });
}

function readerSelNest(_ref) {
  var dogs = _ref.dogs,
      counts = _ref.counts;
  var stateImport = counts.imports > 0; // default toggle to import if there was an imported dog, and exported otherwise

  if (readerState !== lastReaderState) {
    selToggle = stateImport ? 'imports' : 'exports';
    var test = $toggle.selectAll('option').property('selected', function (d) {
      var sel = d3.select(this).node().value;
      return sel === selToggle;
    });
  } // setting container height


  if (counts[selToggle] >= 60) {
    $container.classed('is-clipped', true);
    $transparency.classed('is-visible', true);
    $moreButton.property('disabled', false).classed('is-disabled', false);
  } else {
    $container.classed('is-clipped', false);
    $transparency.classed('is-visible', false);
    $moreButton.property('disabled', true).classed('is-disabled', true);
  } // show a warning when there were no dogs moved in or out of the state


  var noDogsMoved = counts[selToggle] === 0;
  $warning.classed('is-visible', noDogsMoved);

  if (noDogsMoved) {
    $warning.select('.userState').text(readerState);
    $warning.select('.condition').text(selToggle === 'imports' ? 'imported from' : 'exported');
  }

  var nested = d3.nest().key(function (d) {
    return selToggle === 'exports' ? d.final_state : d.original_state;
  }).key(function (d) {
    return d.file;
  }).rollup(function (leaves) {
    return leaves.length;
  }).entries(dogs[selToggle]);
  var countsMap = d3.map(counts, function (d) {
    return d.key;
  });
  var nestedExports = d3.nest().key(function (d) {
    return selToggle === 'exports' ? d.final_state : d.original_state;
  }).entries(dogs[selToggle]).sort(function (a, b) {
    return d3.descending(a.values.length, b.values.length);
  });
  lastReaderState = readerState;
  return nestedExports;
}

function nestDogs(loc, toggle) {
  readerState = loc;
  selToggle = toggle; // filter exported dogs

  var filteredImports = exportedDogs.filter(function (d) {
    return d.final_state === readerState;
  });
  var filteredExports = exportedDogs.filter(function (d) {
    return d.original_state === readerState;
  });
  var allDogs = {
    imports: filteredImports,
    exports: filteredExports
  };
  var dogCounts = {
    imports: filteredImports.length,
    exports: filteredExports.length
  };
  var nestedExports = readerSelNest({
    dogs: allDogs,
    counts: dogCounts
  });
  return nestedExports;
}

function updateLocation(loc) {
  var nestedExports = nestDogs(loc, selToggle);
  charts.data(nestedExports);
}

function filterDogs(loc) {
  var nestedExports = nestDogs(loc, selToggle);
  charts = $section.select('.figure-container').datum(nestedExports).exportsByState();
}

function cleanData(arr) {
  return arr.map(function (d, i) {
    return _objectSpread({}, d, {
      name: d.name.replace(/ *\([^)]*\) */g, "").replace('Adopted', '').replace('Pending', ''),
      highlighted: exampleDogs.includes(d.id)
    });
  });
} // code for determining user's location and subsequent data


function resize() {}

function init(loc) {
  return new Promise(function (resolve, reject) {
    var files = ['exampleDogs.json', 'exportedDogs.csv'];
    var loads = files.map(_loadData.default.loadAny);
    Promise.all(loads).then(function (_ref2) {
      var _ref3 = _slicedToArray(_ref2, 2),
          exampleDogsData = _ref3[0],
          exportedDogsData = _ref3[1];

      exampleDogs = exampleDogsData.map(function (d) {
        return d.id;
      });
      exportedDogs = cleanData(exportedDogsData);
      readerState = loc;
      filterDogs(loc, selToggle); // setup interaction with show more button

      setupExpand();
      setupToggle();
      resolve();
    }).catch(console.error);
  });
}

var _default = {
  init: init,
  resize: resize,
  updateLocation: updateLocation
};
exports.default = _default;
},{"./load-data":"xZJw","./pudding-chart/exports-template":"HYmN"}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: '2018_02_stand-up',
  url: '2018/02/stand-up',
  hed: 'The Structure of Stand-Up Comedy'
}, {
  image: '2018_04_birthday-paradox',
  url: '2018/04/birthday-paradox',
  hed: 'The Birthday Paradox Experiment'
}, {
  image: '2018_11_boy-bands',
  url: '2018/11/boy-bands',
  hed: 'Internet Boy Band Database'
}, {
  image: '2018_08_pockets',
  url: '2018/08/pockets',
  hed: 'Women’s Pockets are Inferior'
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName('script')[0];
  var script = document.createElement('script');
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === 'function') {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open('GET', url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join('');
  d3.select('.pudding-footer .footer-recirc__articles').html(html);
}

function setupSocialJS() {
  // facebook
  (function (d, s, id) {
    var js;
    var fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s);
    js.id = id;
    js.src = '//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7';
    fjs.parentNode.insertBefore(js, fjs);
  })(document, 'script', 'facebook-jssdk');

  loadJS('https://platform.twitter.com/widgets.js');
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
    setupSocialJS();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"osrT":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = [{
  state: 'Alabama',
  abbr: 'AL'
}, {
  state: 'Alaska',
  abbr: 'AK'
}, {
  state: 'Arizona',
  abbr: 'AZ'
}, {
  state: 'Arkansas',
  abbr: 'AR'
}, {
  state: 'California',
  abbr: 'CA'
}, {
  state: 'Colorado',
  abbr: 'CO'
}, {
  state: 'Connecticut',
  abbr: 'CT'
}, {
  state: 'Delaware',
  abbr: 'DE'
}, {
  state: 'Florida',
  abbr: 'FL'
}, {
  state: 'Georgia',
  abbr: 'GA'
}, {
  state: 'Hawaii',
  abbr: 'HI'
}, {
  state: 'Idaho',
  abbr: 'ID'
}, {
  state: 'Illinois',
  abbr: 'IL'
}, {
  state: 'Indiana',
  abbr: 'IN'
}, {
  state: 'Iowa',
  abbr: 'IA'
}, {
  state: 'Kansas',
  abbr: 'KS'
}, {
  state: 'Kentucky',
  abbr: 'KY'
}, {
  state: 'Louisiana',
  abbr: 'LA'
}, {
  state: 'Maine',
  abbr: 'ME'
}, {
  state: 'Montana',
  abbr: 'MT'
}, {
  state: 'Nebraska',
  abbr: 'NE'
}, {
  state: 'Nevada',
  abbr: 'NV'
}, {
  state: 'New Hampshire',
  abbr: 'NH'
}, {
  state: 'New Jersey',
  abbr: 'NJ'
}, {
  state: 'New Mexico',
  abbr: 'NM'
}, {
  state: 'New York',
  abbr: 'NY'
}, {
  state: 'North Carolina',
  abbr: 'NC'
}, {
  state: 'North Dakota',
  abbr: 'ND'
}, {
  state: 'Ohio',
  abbr: 'OH'
}, {
  state: 'Oklahoma',
  abbr: 'OK'
}, {
  state: 'Oregon',
  abbr: 'OR'
}, {
  state: 'Maryland',
  abbr: 'MD'
}, {
  state: 'Massachusetts',
  abbr: 'MA'
}, {
  state: 'Michigan',
  abbr: 'MI'
}, {
  state: 'Minnesota',
  abbr: 'MN'
}, {
  state: 'Mississippi',
  abbr: 'MS'
}, {
  state: 'Missouri',
  abbr: 'MO'
}, {
  state: 'Pennsylvania',
  abbr: 'PA'
}, {
  state: 'Rhode Island',
  abbr: 'RI'
}, {
  state: 'South Carolina',
  abbr: 'SC'
}, {
  state: 'South Dakota',
  abbr: 'SD'
}, {
  state: 'Tennessee',
  abbr: 'TN'
}, {
  state: 'Texas',
  abbr: 'TX'
}, {
  state: 'Utah',
  abbr: 'UT'
}, {
  state: 'Vermont',
  abbr: 'VT'
}, {
  state: 'Virginia',
  abbr: 'VA'
}, {
  state: 'Washington',
  abbr: 'WA'
}, {
  state: 'West Virginia',
  abbr: 'WV'
}, {
  state: 'Wisconsin',
  abbr: 'WI'
}, {
  state: 'Wyoming',
  abbr: 'WY'
}, {
  state: 'Washington DC',
  abbr: 'DC'
}];
exports.default = _default;
},{}],"bcyP":[function(require,module,exports) {
/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.northernLine = function init(options) {
  function createChart(el) {
    var $sel = d3.select(el);

    var _data = $sel.datum(); // dimension stuff


    var width = 0;
    var height = 0;
    var marginTop = 50;
    var marginBottom = 50;
    var marginLeft = 50;
    var marginRight = 50;
    var leftLine = 0;
    var rightLine = 0;
    var startPoint = 0; // scales
    // const scaleX = d3.scaleLinear();

    var scaleY = d3.scaleLinear();
    var scaleStroke = d3.scaleLinear(); // dom elements

    var $svg = null;
    var $axis = null;
    var $vis = null; // helper functions

    var Chart = {
      // called once at start
      init: function init() {
        $svg = $sel.append('svg').attr('class', 'northern-chart');
        var $g = $svg.append('g'); // offset chart for margins

        $g.attr('transform', "translate(".concat(marginLeft, ", ").concat(marginTop, ")")); // create axis

        $axis = $svg.append('g').attr('class', 'g-axis'); // setup viz group

        $vis = $g.append('g').attr('class', 'g-vis');
        Chart.resize();
        Chart.render();
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        width = $sel.node().offsetWidth - marginLeft - marginRight;
        height = $sel.node().offsetHeight - marginTop - marginBottom;
        $svg.attr('width', width + marginLeft + marginRight).attr('height', height + marginTop + marginBottom);
        scaleY.range([height, 0]).domain(d3.extent(_data, function (d) {
          return d.latDiff;
        }));
        scaleStroke.range([width * 0.01, width * 0.1]).domain(d3.extent(_data, function (d) {
          return d.n;
        }));
        console.log(scaleStroke(104));
        console.log(scaleStroke(5));
        leftLine = width * 0.25;
        rightLine = width * 0.75;
        startPoint = scaleY(0);
        return Chart;
      },
      // update scales and render chart
      render: function render() {
        // add circles to each end point
        $vis.selectAll('.end-point').data(_data).join(function (enter) {
          // enter.append('circle')
          // 	.attr('class', 'end-point')
          // 	.attr('r', 5)
          // 	.attr('cx', rightLine)
          // 	.attr('cy', d => scaleY(d.latDiff))
          // enter.append('line')
          // 	.attr('class', 'move-line')
          // 	.attr('x1', leftLine)
          // 	.attr('x2', rightLine)
          // 	.attr('y1', startPoint)
          // 	.attr('y2', d => scaleY(d.latDiff))
          // 	.style('stroke-width', d => `${Math.round(scaleStroke(d.n))}px`)
          // 	.style('stroke', d => d.latDiff >= 0 ? '#E69E9E' : '#DF753C')
          enter.append('path').attr('class', 'move-path').attr('d', function (d) {
            var padding = width * 0.2;
            var starting = [leftLine, startPoint];
            var ending = [rightLine, scaleY(d.latDiff)];
            var startControl = [leftLine + (padding + scaleStroke(d.n)), startPoint];
            var endControl = [rightLine - padding, scaleY(d.latDiff)];
            var backStart = [rightLine - (padding + scaleStroke(d.n)), scaleY(d.latDiff)];
            var backEnd = [leftLine + padding, startPoint];
            var path = [// move to starting point
            'M', starting, // add cubic bezier curve
            'C', startControl, endControl, // add end point
            ending, 'C', backStart, backEnd, starting];
            var joined = path.join(' ');
            return joined;
          }).style('fill', function (d) {
            return d.latDiff >= 0 ? '#E69E9E' : '#DF753C';
          }); // .style('stroke-width', '1px')
          // .style('stroke', d => d.latDiff >= 0 ? '#E69E9E' : '#DF753C')
        }, function (update) {
          update.attr('cx', rightLine).attr('cy', function (d) {
            return scaleY(d.latDiff);
          });
        }); // add point to starting point

        $vis.append('circle').attr('class', 'starting-point').attr('r', 5).attr('cx', leftLine).attr('cy', startPoint).raise();
        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $sel.datum(_data);
        Chart.render();
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"dOkl":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

require("./pudding-chart/northern-template");

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// selections
var $section = d3.select('.northern');
var $container = $section.select('.figure-container'); // data

var movementData = null;

function cleanData(arr) {
  return arr.map(function (d, i) {
    return _objectSpread({}, d, {
      latDiff: +d.latDiff,
      n: +d.n
    });
  });
}

function setup() {
  var filtered = movementData.filter(function (d) {
    return d.inUS === 'TRUE';
  }).sort(function (d) {
    return d3.descending(d.n);
  });
  var sorted = movementData.sort(function (d) {
    return d3.ascending(d.n);
  });
  var chart = $container.datum(filtered).northernLine();
}

function resize() {}

function init() {
  _loadData.default.loadCSV('northernMovement.csv').then(function (result) {
    movementData = cleanData(result);
    setup();
  }).catch(console.error);
}

var _default = {
  resize: resize,
  init: init
};
exports.default = _default;
},{"./pudding-chart/northern-template":"bcyP","./load-data":"xZJw"}],"uAm8":[function(require,module,exports) {
/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.tileMap = function init(options) {
  function createChart(el) {
    var $sel = d3.select(el);

    var _data = $sel.datum();

    var rendered = false; // dimension stuff

    var width = 0;
    var textHeight = 18;
    var containerHeight = null;
    var isMobile = false;
    var $container = d3.select('.movement');
    var $legendScale = $container.select('.legend-scale'); // factor to determine how many dogs should be
    // equal to one block

    var factor = isMobile === true ? 2 : 4; // helper functions

    function addDogBlocks(_ref) {
      var $imports = _ref.$imports,
          $exports = _ref.$exports,
          factor = _ref.factor;

      if (_data.count) {
        $imports.selectAll('.import dog').data(d3.range(_data.count.imported / factor)).join(function (enter) {
          enter.append('div').attr('class', 'import');
        });
        $exports.selectAll('.export dog').data(d3.range(_data.count.exported / factor)).join(function (enter) {
          enter.append('div').attr('class', 'export');
        });
      }
    }

    var Chart = {
      // called once at start
      init: function init() {
        Chart.resize();
        Chart.render();
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        if (_data.location === 'Maine') {
          width = $sel.node().offsetWidth;
          $sel.style('height', "".concat(width * 0.7, "px"));
        } else {
          width = d3.select('.block-Maine').node().offsetWidth;
          $sel.style('height', "".concat(width * 0.7, "px"));
        }

        var windowWidth = window.innerWidth;
        isMobile = windowWidth <= 600;
        factor = isMobile === true ? 20 : 4;
        $legendScale.text("".concat(factor)); // container height should be height - text height

        containerHeight = width * 0.7 - textHeight; // resize entire bounding chart once

        if (_data.location === 'Florida') {
          var $figure = d3.select('.movement-figure');
          var $bound = $figure.select('.figure-container').style('height', "".concat(width * 8, "px"));
        }

        var $imports = $sel.select('.container-imports');
        var $exports = $sel.select('.container-exports'); // if the blocks have already been drawn

        if (rendered && _data.location !== 'blank') {
          // console.log({factor})
          // addDogBlocks({$imports, $exports, factor})
          $imports.selectAll('.import').data(d3.range(_data.count.imported / factor)).join(function (update) {
            update.append('div').attr('class', 'export').style('background-color', 'red');
          });
          $exports.selectAll('.export').data(d3.range(_data.count.exported / factor)).join(function (update) {
            update.append('div').attr('class', 'export');
          });
        }

        return Chart;
      },
      // update scales and render chart
      render: function render() {
        rendered = true;

        if (_data.location != 'blank') {
          // add div for chart
          var _$container = $sel.append('div').attr('class', 'container').style('height', "".concat(containerHeight, "px")); // add containers for imports and exports


          var $imports = _$container.append('div').attr('class', 'container-imports');

          var $exports = _$container.append('div').attr('class', 'container-exports'); // add state name


          var $nameDiv = $sel.append('div').attr('class', 'name-div');
          $nameDiv.append('span').text(_data.abbreviation).attr('class', 'name name-upper');
          addDogBlocks({
            $imports: $imports,
            $exports: $exports,
            factor: factor
          }); // if the data exists for that state, add dogs
          // if (data.count){
          // 		$imports.selectAll('.import dog')
          // 			.data(d3.range(data.count.imported / factor))
          // 			.join(enter => {
          // 				enter.append('div')
          // 					.attr('class', 'import')
          // 			})
          //
          // 	$exports.selectAll('.export dog')
          // 		.data(d3.range(data.count.exported / factor))
          // 		.join(enter => {
          // 			enter.append('div')
          // 				.attr('class', 'export')
          // 		})
          // }
        }

        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $sel.datum(_data);
        Chart.render();
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"NDWt":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _usStateData = _interopRequireDefault(require("./us-state-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Return state abbrevation from name
 * @param {string} state to use to lookup abbreviation

 * @returns {string} abbreviation
 */
function lookupStateAbbr(state) {
  var match = _usStateData.default.find(function (d) {
    return d.state.toLowerCase() === state.toLowerCase();
  });

  return match ? match.abbr : null;
}

var _default = lookupStateAbbr;
exports.default = _default;
},{"./us-state-data":"osrT"}],"KRMc":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/tile-template");

var _lookupStateAbbr = _interopRequireDefault(require("./utils/lookup-state-abbr"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// data
var importExport = null;
var tileLoc = null; // selections

var $section = d3.select('.movement');
var $container = $section.select('.figure-container');
var $tooltip = $section.select('.movement-tooltip'); // charts

var charts = null;
var width = null;

function handleMouseover() {
  var sel = d3.select(this);
  var state = sel.attr('data-state'); // $tooltip
  // 	.style('left', `${d3.event.pageX}px`)
  // 	.style('top', `${d3.event.pageY}px`)
  // 	.classed('is-hidden', false)

  if (state !== 'blank') {
    var imported = sel.attr('data-imported');
    var exported = sel.attr('data-exported');
    $tooltip.select('.tooltip-state').text(sel.attr('data-state'));
    $tooltip.select('.tooltip-count-import').text(imported);
    $tooltip.select('.tooltip-count-export').text(exported);
    $tooltip.classed('is-hidden', false);
  } else $tooltip.classed('is-hidden', true);

  var mouseX = d3.event.pageX; // const mouseY = d3.event.pageY
  // const toolTipHeight = $tooltip.node().offsetHeight;

  var toolTipWidth = $tooltip.node().offsetWidth;
  $tooltip.style('left', function () {
    var xMove = mouseX;
    if (mouseX > 0.5 * width) xMove -= toolTipWidth;
    return "".concat(xMove, "px");
  }).style('top', "".concat(d3.event.pageY, "px")).classed('is-hidden', false);
}

function cleanData(arr) {
  return arr.map(function (d, i) {
    return _objectSpread({}, d, {
      imported: +d.imported,
      exported: +d.exported,
      number: i
    });
  });
}

function setup() {
  var locationMap = d3.map(importExport, function (d) {
    return d.location;
  }); // add data to tile location

  var tileData = tileLoc.map(function (d, i) {
    return {
      location: d,
      gridNumber: i + 1,
      count: locationMap.get(d),
      abbreviation: d === 'blank' ? null : (0, _lookupStateAbbr.default)(d)
    };
  });
  charts = $container.selectAll('.grid-block').data(tileData).join(function (enter) {
    return enter.append('div').attr('class', function (d) {
      return "grid-block block-".concat(d.location);
    }).attr('data-state', function (d) {
      return d.location;
    }).attr('data-imported', function (d) {
      return d.count ? d.count.imported : null;
    }).attr('data-exported', function (d) {
      return d.count ? d.count.exported : null;
    }).on('mouseover', handleMouseover);
  }).tileMap();
}

function loadLocations() {
  _loadData.default.loadJSON('tile-locations.json').then(function (result) {
    tileLoc = result;
    setup();
  }).catch(console.error);
}

function resize() {
  width = $section.node().offsetWidth;
  if (charts) charts.forEach(function (d) {
    return d.resize();
  });
}

function init() {
  _loadData.default.loadCSV('importExport.csv').then(function (result) {
    importExport = cleanData(result);
    loadLocations();
    resize();
  }).catch(console.error);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw","./pudding-chart/tile-template":"uAm8","./utils/lookup-state-abbr":"NDWt"}],"countries.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var $section = d3.select('.countries');
var $container = $section.select('.figure-container');
var $table = $container.select('table');
var $toggles = $section.selectAll('.toggle');
var $moreButton = $section.select('.show-more');
var $transparency = $section.select('.transparency');
var $checkboxes = $section.selectAll('input');
var $warning = $section.select('.figure-warning');
var rank = null;
var selButton = 'All';
var conditions = {
  domestic: true,
  international: true
};
var COLUMNS = [{
  title: 'Rank',
  prop: 'i'
}, {
  title: 'Location',
  prop: 'location'
}, {
  title: '# Exported',
  prop: 'exported'
}];

function cleanData(arr) {
  return arr.map(function (d, i) {
    return _objectSpread({}, d, {
      imported: +d.imported,
      exported: +d.exported,
      international: d.inUS === 'false'
    });
  });
}

function setupTableHeader() {
  // adding table header
  $table.append('thead').selectAll('th').data(COLUMNS).join(function (enter) {
    return enter.append('th').text(function (d) {
      return d.title;
    });
  });
  $table.append('tbody');
}

function setupExpand() {
  $moreButton.on('click', function () {
    var truncated = $container.classed('is-truncated');
    var text = truncated ? 'Show Fewer' : 'Show All';
    $moreButton.text(text);
    $container.classed('is-truncated', !truncated);

    if (!truncated) {
      var y = +$moreButton.attr('data-y');
      window.scrollTo(0, y);
    }

    $moreButton.attr('data-y', window.scrollY);
    $transparency.classed('is-visible', !truncated);
  });
}

function setupToggles() {
  $checkboxes.on('change', function (d) {
    var box = d3.select(this);
    var condition = box.node().checked;

    var _box$node = box.node(),
        value = _box$node.value;

    conditions[value] = condition;
    filter(conditions);
  });
}

function setup() {
  //   const header = $container.append('div').attr('class', 'header');
  //   header
  //     .append('p')
  //     .attr('class', 'location-rank')
  //     .text('Rank');
  //   header
  //     .append('p')
  //     .attr('class', 'location-name')
  //     .text('Location');
  //   header
  //     .append('p')
  //     .attr('class', 'location-count')
  //     .text('# Exported');
  setupTableHeader();
  setupToggles();
  setupExpand();
  filter(conditions);
}

function filter(conditions) {
  var filtered = null;

  if (conditions.international || conditions.domestic) {
    $warning.classed('is-hidden', true);
    $container.classed('is-hidden', false);
    $transparency.classed('is-visible', true);
    $moreButton.classed('is-disabled', false);
    if (conditions.international && conditions.domestic) filtered = rank;else if (conditions.international) filtered = rank.filter(function (d) {
      return d.international === true;
    });else if (conditions.domestic) filtered = rank.filter(function (d) {
      return d.international === false;
    });
  } else if (!(conditions.international && conditions.domestic)) {
    $warning.classed('is-hidden', false);
    $container.classed('is-hidden', true);
    $transparency.classed('is-visible', false);
    $moreButton.classed('is-disabled', true);
  } // adding semantic table


  var getRowData = function getRowData(d, i) {
    return COLUMNS.map(function (c) {
      return {
        value: d[c.prop],
        title: c.title,
        rank: i
      };
    });
  };

  var $row = $table.select('tbody').selectAll('tr').data(filtered, function (d, i) {
    return "".concat(d.location, "-").concat(i);
  }).join(function (enter) {
    return enter.append('tr');
  });
  $row.selectAll('td').data(getRowData, function (d) {
    return "".concat(d.value).concat(d.rank);
  }).join(function (enter) {
    return enter.append('td').attr('class', function (d) {
      return "".concat(d.title);
    });
  }).text(function (d) {
    if (d.title === 'Rank') return d.rank + 1;
    return d.value;
  });
}

function resize() {}

function init() {
  _loadData.default.loadCSV('importExport.csv').then(function (result) {
    rank = cleanData(result).filter(function (d) {
      return d.exported > 0;
    });
    setup(); // setup interaction with show more button
    // setupExpand()
  }).catch(console.error);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw"}],"PHwb":[function(require,module,exports) {

/**
 * Expose `Emitter`.
 */

if (typeof module !== 'undefined') {
  module.exports = Emitter;
}

/**
 * Initialize a new `Emitter`.
 *
 * @api public
 */

function Emitter(obj) {
  if (obj) return mixin(obj);
};

/**
 * Mixin the emitter properties.
 *
 * @param {Object} obj
 * @return {Object}
 * @api private
 */

function mixin(obj) {
  for (var key in Emitter.prototype) {
    obj[key] = Emitter.prototype[key];
  }
  return obj;
}

/**
 * Listen on the given `event` with `fn`.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.on =
Emitter.prototype.addEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};
  (this._callbacks['$' + event] = this._callbacks['$' + event] || [])
    .push(fn);
  return this;
};

/**
 * Adds an `event` listener that will be invoked a single
 * time then automatically removed.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.once = function(event, fn){
  function on() {
    this.off(event, on);
    fn.apply(this, arguments);
  }

  on.fn = fn;
  this.on(event, on);
  return this;
};

/**
 * Remove the given callback for `event` or all
 * registered callbacks.
 *
 * @param {String} event
 * @param {Function} fn
 * @return {Emitter}
 * @api public
 */

Emitter.prototype.off =
Emitter.prototype.removeListener =
Emitter.prototype.removeAllListeners =
Emitter.prototype.removeEventListener = function(event, fn){
  this._callbacks = this._callbacks || {};

  // all
  if (0 == arguments.length) {
    this._callbacks = {};
    return this;
  }

  // specific event
  var callbacks = this._callbacks['$' + event];
  if (!callbacks) return this;

  // remove all handlers
  if (1 == arguments.length) {
    delete this._callbacks['$' + event];
    return this;
  }

  // remove specific handler
  var cb;
  for (var i = 0; i < callbacks.length; i++) {
    cb = callbacks[i];
    if (cb === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
  }

  // Remove event specific arrays for event types that no
  // one is subscribed for to avoid memory leak.
  if (callbacks.length === 0) {
    delete this._callbacks['$' + event];
  }

  return this;
};

/**
 * Emit `event` with the given args.
 *
 * @param {String} event
 * @param {Mixed} ...
 * @return {Emitter}
 */

Emitter.prototype.emit = function(event){
  this._callbacks = this._callbacks || {};

  var args = new Array(arguments.length - 1)
    , callbacks = this._callbacks['$' + event];

  for (var i = 1; i < arguments.length; i++) {
    args[i - 1] = arguments[i];
  }

  if (callbacks) {
    callbacks = callbacks.slice(0);
    for (var i = 0, len = callbacks.length; i < len; ++i) {
      callbacks[i].apply(this, args);
    }
  }

  return this;
};

/**
 * Return array of callbacks for `event`.
 *
 * @param {String} event
 * @return {Array}
 * @api public
 */

Emitter.prototype.listeners = function(event){
  this._callbacks = this._callbacks || {};
  return this._callbacks['$' + event] || [];
};

/**
 * Check if this emitter has `event` handlers.
 *
 * @param {String} event
 * @return {Boolean}
 * @api public
 */

Emitter.prototype.hasListeners = function(event){
  return !! this.listeners(event).length;
};

},{}],"L4M6":[function(require,module,exports) {
module.exports = stringify
stringify.default = stringify
stringify.stable = deterministicStringify
stringify.stableStringify = deterministicStringify

var arr = []

// Regular stringify
function stringify (obj, replacer, spacer) {
  decirc(obj, '', [], undefined)
  var res = JSON.stringify(obj, replacer, spacer)
  while (arr.length !== 0) {
    var part = arr.pop()
    part[0][part[1]] = part[2]
  }
  return res
}
function decirc (val, k, stack, parent) {
  var i
  if (typeof val === 'object' && val !== null) {
    for (i = 0; i < stack.length; i++) {
      if (stack[i] === val) {
        parent[k] = '[Circular]'
        arr.push([parent, k, val])
        return
      }
    }
    stack.push(val)
    // Optimize for Arrays. Big arrays could kill the performance otherwise!
    if (Array.isArray(val)) {
      for (i = 0; i < val.length; i++) {
        decirc(val[i], i, stack, val)
      }
    } else {
      var keys = Object.keys(val)
      for (i = 0; i < keys.length; i++) {
        var key = keys[i]
        decirc(val[key], key, stack, val)
      }
    }
    stack.pop()
  }
}

// Stable-stringify
function compareFunction (a, b) {
  if (a < b) {
    return -1
  }
  if (a > b) {
    return 1
  }
  return 0
}

function deterministicStringify (obj, replacer, spacer) {
  var tmp = deterministicDecirc(obj, '', [], undefined) || obj
  var res = JSON.stringify(tmp, replacer, spacer)
  while (arr.length !== 0) {
    var part = arr.pop()
    part[0][part[1]] = part[2]
  }
  return res
}

function deterministicDecirc (val, k, stack, parent) {
  var i
  if (typeof val === 'object' && val !== null) {
    for (i = 0; i < stack.length; i++) {
      if (stack[i] === val) {
        parent[k] = '[Circular]'
        arr.push([parent, k, val])
        return
      }
    }
    if (typeof val.toJSON === 'function') {
      return
    }
    stack.push(val)
    // Optimize for Arrays. Big arrays could kill the performance otherwise!
    if (Array.isArray(val)) {
      for (i = 0; i < val.length; i++) {
        deterministicDecirc(val[i], i, stack, val)
      }
    } else {
      // Create a temporary object in the required way
      var tmp = {}
      var keys = Object.keys(val).sort(compareFunction)
      for (i = 0; i < keys.length; i++) {
        var key = keys[i]
        deterministicDecirc(val[key], key, stack, val)
        tmp[key] = val[key]
      }
      if (parent !== undefined) {
        arr.push([parent, k, val])
        parent[k] = tmp
      } else {
        return tmp
      }
    }
    stack.pop()
  }
}

},{}],"ymYf":[function(require,module,exports) {
"use strict";

function _typeof(obj) {
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}
/**
 * Check if `obj` is an object.
 *
 * @param {Object} obj
 * @return {Boolean}
 * @api private
 */


function isObject(obj) {
  return obj !== null && _typeof(obj) === 'object';
}

module.exports = isObject;
},{}],"zs9O":[function(require,module,exports) {
"use strict";

function _typeof(obj) {
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}
/**
 * Module of mixed-in functions shared between node and client code
 */


var isObject = require('./is-object');
/**
 * Expose `RequestBase`.
 */


module.exports = RequestBase;
/**
 * Initialize a new `RequestBase`.
 *
 * @api public
 */

function RequestBase(obj) {
  if (obj) return mixin(obj);
}
/**
 * Mixin the prototype properties.
 *
 * @param {Object} obj
 * @return {Object}
 * @api private
 */


function mixin(obj) {
  for (var key in RequestBase.prototype) {
    if (Object.prototype.hasOwnProperty.call(RequestBase.prototype, key)) obj[key] = RequestBase.prototype[key];
  }

  return obj;
}
/**
 * Clear previous timeout.
 *
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.clearTimeout = function () {
  clearTimeout(this._timer);
  clearTimeout(this._responseTimeoutTimer);
  clearTimeout(this._uploadTimeoutTimer);
  delete this._timer;
  delete this._responseTimeoutTimer;
  delete this._uploadTimeoutTimer;
  return this;
};
/**
 * Override default response body parser
 *
 * This function will be called to convert incoming data into request.body
 *
 * @param {Function}
 * @api public
 */


RequestBase.prototype.parse = function (fn) {
  this._parser = fn;
  return this;
};
/**
 * Set format of binary response body.
 * In browser valid formats are 'blob' and 'arraybuffer',
 * which return Blob and ArrayBuffer, respectively.
 *
 * In Node all values result in Buffer.
 *
 * Examples:
 *
 *      req.get('/')
 *        .responseType('blob')
 *        .end(callback);
 *
 * @param {String} val
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.responseType = function (val) {
  this._responseType = val;
  return this;
};
/**
 * Override default request body serializer
 *
 * This function will be called to convert data set via .send or .attach into payload to send
 *
 * @param {Function}
 * @api public
 */


RequestBase.prototype.serialize = function (fn) {
  this._serializer = fn;
  return this;
};
/**
 * Set timeouts.
 *
 * - response timeout is time between sending request and receiving the first byte of the response. Includes DNS and connection time.
 * - deadline is the time from start of the request to receiving response body in full. If the deadline is too short large files may not load at all on slow connections.
 * - upload is the time  since last bit of data was sent or received. This timeout works only if deadline timeout is off
 *
 * Value of 0 or false means no timeout.
 *
 * @param {Number|Object} ms or {response, deadline}
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.timeout = function (options) {
  if (!options || _typeof(options) !== 'object') {
    this._timeout = options;
    this._responseTimeout = 0;
    this._uploadTimeout = 0;
    return this;
  }

  for (var option in options) {
    if (Object.prototype.hasOwnProperty.call(options, option)) {
      switch (option) {
        case 'deadline':
          this._timeout = options.deadline;
          break;

        case 'response':
          this._responseTimeout = options.response;
          break;

        case 'upload':
          this._uploadTimeout = options.upload;
          break;

        default:
          console.warn('Unknown timeout option', option);
      }
    }
  }

  return this;
};
/**
 * Set number of retry attempts on error.
 *
 * Failed requests will be retried 'count' times if timeout or err.code >= 500.
 *
 * @param {Number} count
 * @param {Function} [fn]
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.retry = function (count, fn) {
  // Default to 1 if no count passed or true
  if (arguments.length === 0 || count === true) count = 1;
  if (count <= 0) count = 0;
  this._maxRetries = count;
  this._retries = 0;
  this._retryCallback = fn;
  return this;
};

var ERROR_CODES = ['ECONNRESET', 'ETIMEDOUT', 'EADDRINFO', 'ESOCKETTIMEDOUT'];
/**
 * Determine if a request should be retried.
 * (Borrowed from segmentio/superagent-retry)
 *
 * @param {Error} err an error
 * @param {Response} [res] response
 * @returns {Boolean} if segment should be retried
 */

RequestBase.prototype._shouldRetry = function (err, res) {
  if (!this._maxRetries || this._retries++ >= this._maxRetries) {
    return false;
  }

  if (this._retryCallback) {
    try {
      var override = this._retryCallback(err, res);

      if (override === true) return true;
      if (override === false) return false; // undefined falls back to defaults
    } catch (err2) {
      console.error(err2);
    }
  }

  if (res && res.status && res.status >= 500 && res.status !== 501) return true;

  if (err) {
    if (err.code && ERROR_CODES.indexOf(err.code) !== -1) return true; // Superagent timeout

    if (err.timeout && err.code === 'ECONNABORTED') return true;
    if (err.crossDomain) return true;
  }

  return false;
};
/**
 * Retry request
 *
 * @return {Request} for chaining
 * @api private
 */


RequestBase.prototype._retry = function () {
  this.clearTimeout(); // node

  if (this.req) {
    this.req = null;
    this.req = this.request();
  }

  this._aborted = false;
  this.timedout = false;
  return this._end();
};
/**
 * Promise support
 *
 * @param {Function} resolve
 * @param {Function} [reject]
 * @return {Request}
 */


RequestBase.prototype.then = function (resolve, reject) {
  var _this = this;

  if (!this._fullfilledPromise) {
    var self = this;

    if (this._endCalled) {
      console.warn('Warning: superagent request was sent twice, because both .end() and .then() were called. Never call .end() if you use promises');
    }

    this._fullfilledPromise = new Promise(function (resolve, reject) {
      self.on('abort', function () {
        var err = new Error('Aborted');
        err.code = 'ABORTED';
        err.status = _this.status;
        err.method = _this.method;
        err.url = _this.url;
        reject(err);
      });
      self.end(function (err, res) {
        if (err) reject(err);else resolve(res);
      });
    });
  }

  return this._fullfilledPromise.then(resolve, reject);
};

RequestBase.prototype.catch = function (cb) {
  return this.then(undefined, cb);
};
/**
 * Allow for extension
 */


RequestBase.prototype.use = function (fn) {
  fn(this);
  return this;
};

RequestBase.prototype.ok = function (cb) {
  if (typeof cb !== 'function') throw new Error('Callback required');
  this._okCallback = cb;
  return this;
};

RequestBase.prototype._isResponseOK = function (res) {
  if (!res) {
    return false;
  }

  if (this._okCallback) {
    return this._okCallback(res);
  }

  return res.status >= 200 && res.status < 300;
};
/**
 * Get request header `field`.
 * Case-insensitive.
 *
 * @param {String} field
 * @return {String}
 * @api public
 */


RequestBase.prototype.get = function (field) {
  return this._header[field.toLowerCase()];
};
/**
 * Get case-insensitive header `field` value.
 * This is a deprecated internal API. Use `.get(field)` instead.
 *
 * (getHeader is no longer used internally by the superagent code base)
 *
 * @param {String} field
 * @return {String}
 * @api private
 * @deprecated
 */


RequestBase.prototype.getHeader = RequestBase.prototype.get;
/**
 * Set header `field` to `val`, or multiple fields with one object.
 * Case-insensitive.
 *
 * Examples:
 *
 *      req.get('/')
 *        .set('Accept', 'application/json')
 *        .set('X-API-Key', 'foobar')
 *        .end(callback);
 *
 *      req.get('/')
 *        .set({ Accept: 'application/json', 'X-API-Key': 'foobar' })
 *        .end(callback);
 *
 * @param {String|Object} field
 * @param {String} val
 * @return {Request} for chaining
 * @api public
 */

RequestBase.prototype.set = function (field, val) {
  if (isObject(field)) {
    for (var key in field) {
      if (Object.prototype.hasOwnProperty.call(field, key)) this.set(key, field[key]);
    }

    return this;
  }

  this._header[field.toLowerCase()] = val;
  this.header[field] = val;
  return this;
}; // eslint-disable-next-line valid-jsdoc

/**
 * Remove header `field`.
 * Case-insensitive.
 *
 * Example:
 *
 *      req.get('/')
 *        .unset('User-Agent')
 *        .end(callback);
 *
 * @param {String} field field name
 */


RequestBase.prototype.unset = function (field) {
  delete this._header[field.toLowerCase()];
  delete this.header[field];
  return this;
};
/**
 * Write the field `name` and `val`, or multiple fields with one object
 * for "multipart/form-data" request bodies.
 *
 * ``` js
 * request.post('/upload')
 *   .field('foo', 'bar')
 *   .end(callback);
 *
 * request.post('/upload')
 *   .field({ foo: 'bar', baz: 'qux' })
 *   .end(callback);
 * ```
 *
 * @param {String|Object} name name of field
 * @param {String|Blob|File|Buffer|fs.ReadStream} val value of field
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.field = function (name, val) {
  // name should be either a string or an object.
  if (name === null || undefined === name) {
    throw new Error('.field(name, val) name can not be empty');
  }

  if (this._data) {
    throw new Error(".field() can't be used if .send() is used. Please use only .send() or only .field() & .attach()");
  }

  if (isObject(name)) {
    for (var key in name) {
      if (Object.prototype.hasOwnProperty.call(name, key)) this.field(key, name[key]);
    }

    return this;
  }

  if (Array.isArray(val)) {
    for (var i in val) {
      if (Object.prototype.hasOwnProperty.call(val, i)) this.field(name, val[i]);
    }

    return this;
  } // val should be defined now


  if (val === null || undefined === val) {
    throw new Error('.field(name, val) val can not be empty');
  }

  if (typeof val === 'boolean') {
    val = String(val);
  }

  this._getFormData().append(name, val);

  return this;
};
/**
 * Abort the request, and clear potential timeout.
 *
 * @return {Request} request
 * @api public
 */


RequestBase.prototype.abort = function () {
  if (this._aborted) {
    return this;
  }

  this._aborted = true;
  if (this.xhr) this.xhr.abort(); // browser

  if (this.req) this.req.abort(); // node

  this.clearTimeout();
  this.emit('abort');
  return this;
};

RequestBase.prototype._auth = function (user, pass, options, base64Encoder) {
  switch (options.type) {
    case 'basic':
      this.set('Authorization', "Basic ".concat(base64Encoder("".concat(user, ":").concat(pass))));
      break;

    case 'auto':
      this.username = user;
      this.password = pass;
      break;

    case 'bearer':
      // usage would be .auth(accessToken, { type: 'bearer' })
      this.set('Authorization', "Bearer ".concat(user));
      break;

    default:
      break;
  }

  return this;
};
/**
 * Enable transmission of cookies with x-domain requests.
 *
 * Note that for this to work the origin must not be
 * using "Access-Control-Allow-Origin" with a wildcard,
 * and also must set "Access-Control-Allow-Credentials"
 * to "true".
 *
 * @api public
 */


RequestBase.prototype.withCredentials = function (on) {
  // This is browser-only functionality. Node side is no-op.
  if (on === undefined) on = true;
  this._withCredentials = on;
  return this;
};
/**
 * Set the max redirects to `n`. Does nothing in browser XHR implementation.
 *
 * @param {Number} n
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.redirects = function (n) {
  this._maxRedirects = n;
  return this;
};
/**
 * Maximum size of buffered response body, in bytes. Counts uncompressed size.
 * Default 200MB.
 *
 * @param {Number} n number of bytes
 * @return {Request} for chaining
 */


RequestBase.prototype.maxResponseSize = function (n) {
  if (typeof n !== 'number') {
    throw new TypeError('Invalid argument');
  }

  this._maxResponseSize = n;
  return this;
};
/**
 * Convert to a plain javascript object (not JSON string) of scalar properties.
 * Note as this method is designed to return a useful non-this value,
 * it cannot be chained.
 *
 * @return {Object} describing method, url, and data of this request
 * @api public
 */


RequestBase.prototype.toJSON = function () {
  return {
    method: this.method,
    url: this.url,
    data: this._data,
    headers: this._header
  };
};
/**
 * Send `data` as the request body, defaulting the `.type()` to "json" when
 * an object is given.
 *
 * Examples:
 *
 *       // manual json
 *       request.post('/user')
 *         .type('json')
 *         .send('{"name":"tj"}')
 *         .end(callback)
 *
 *       // auto json
 *       request.post('/user')
 *         .send({ name: 'tj' })
 *         .end(callback)
 *
 *       // manual x-www-form-urlencoded
 *       request.post('/user')
 *         .type('form')
 *         .send('name=tj')
 *         .end(callback)
 *
 *       // auto x-www-form-urlencoded
 *       request.post('/user')
 *         .type('form')
 *         .send({ name: 'tj' })
 *         .end(callback)
 *
 *       // defaults to x-www-form-urlencoded
 *      request.post('/user')
 *        .send('name=tobi')
 *        .send('species=ferret')
 *        .end(callback)
 *
 * @param {String|Object} data
 * @return {Request} for chaining
 * @api public
 */
// eslint-disable-next-line complexity


RequestBase.prototype.send = function (data) {
  var isObj = isObject(data);
  var type = this._header['content-type'];

  if (this._formData) {
    throw new Error(".send() can't be used if .attach() or .field() is used. Please use only .send() or only .field() & .attach()");
  }

  if (isObj && !this._data) {
    if (Array.isArray(data)) {
      this._data = [];
    } else if (!this._isHost(data)) {
      this._data = {};
    }
  } else if (data && this._data && this._isHost(this._data)) {
    throw new Error("Can't merge these send calls");
  } // merge


  if (isObj && isObject(this._data)) {
    for (var key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key)) this._data[key] = data[key];
    }
  } else if (typeof data === 'string') {
    // default to x-www-form-urlencoded
    if (!type) this.type('form');
    type = this._header['content-type'];

    if (type === 'application/x-www-form-urlencoded') {
      this._data = this._data ? "".concat(this._data, "&").concat(data) : data;
    } else {
      this._data = (this._data || '') + data;
    }
  } else {
    this._data = data;
  }

  if (!isObj || this._isHost(data)) {
    return this;
  } // default to json


  if (!type) this.type('json');
  return this;
};
/**
 * Sort `querystring` by the sort function
 *
 *
 * Examples:
 *
 *       // default order
 *       request.get('/user')
 *         .query('name=Nick')
 *         .query('search=Manny')
 *         .sortQuery()
 *         .end(callback)
 *
 *       // customized sort function
 *       request.get('/user')
 *         .query('name=Nick')
 *         .query('search=Manny')
 *         .sortQuery(function(a, b){
 *           return a.length - b.length;
 *         })
 *         .end(callback)
 *
 *
 * @param {Function} sort
 * @return {Request} for chaining
 * @api public
 */


RequestBase.prototype.sortQuery = function (sort) {
  // _sort default to true but otherwise can be a function or boolean
  this._sort = typeof sort === 'undefined' ? true : sort;
  return this;
};
/**
 * Compose querystring to append to req.url
 *
 * @api private
 */


RequestBase.prototype._finalizeQueryString = function () {
  var query = this._query.join('&');

  if (query) {
    this.url += (this.url.indexOf('?') >= 0 ? '&' : '?') + query;
  }

  this._query.length = 0; // Makes the call idempotent

  if (this._sort) {
    var index = this.url.indexOf('?');

    if (index >= 0) {
      var queryArr = this.url.substring(index + 1).split('&');

      if (typeof this._sort === 'function') {
        queryArr.sort(this._sort);
      } else {
        queryArr.sort();
      }

      this.url = this.url.substring(0, index) + '?' + queryArr.join('&');
    }
  }
}; // For backwards compat only


RequestBase.prototype._appendQueryString = function () {
  console.warn('Unsupported');
};
/**
 * Invoke callback with timeout error.
 *
 * @api private
 */


RequestBase.prototype._timeoutError = function (reason, timeout, errno) {
  if (this._aborted) {
    return;
  }

  var err = new Error("".concat(reason + timeout, "ms exceeded"));
  err.timeout = timeout;
  err.code = 'ECONNABORTED';
  err.errno = errno;
  this.timedout = true;
  this.abort();
  this.callback(err);
};

RequestBase.prototype._setTimeouts = function () {
  var self = this; // deadline

  if (this._timeout && !this._timer) {
    this._timer = setTimeout(function () {
      self._timeoutError('Timeout of ', self._timeout, 'ETIME');
    }, this._timeout);
  } // response timeout


  if (this._responseTimeout && !this._responseTimeoutTimer) {
    this._responseTimeoutTimer = setTimeout(function () {
      self._timeoutError('Response timeout of ', self._responseTimeout, 'ETIMEDOUT');
    }, this._responseTimeout);
  }
};
},{"./is-object":"ymYf"}],"4wfi":[function(require,module,exports) {
"use strict";
/**
 * Return the mime type for the given `str`.
 *
 * @param {String} str
 * @return {String}
 * @api private
 */

exports.type = function (str) {
  return str.split(/ *; */).shift();
};
/**
 * Return header field parameters.
 *
 * @param {String} str
 * @return {Object}
 * @api private
 */


exports.params = function (str) {
  return str.split(/ *; */).reduce(function (obj, str) {
    var parts = str.split(/ *= */);
    var key = parts.shift();
    var val = parts.shift();
    if (key && val) obj[key] = val;
    return obj;
  }, {});
};
/**
 * Parse Link header fields.
 *
 * @param {String} str
 * @return {Object}
 * @api private
 */


exports.parseLinks = function (str) {
  return str.split(/ *, */).reduce(function (obj, str) {
    var parts = str.split(/ *; */);
    var url = parts[0].slice(1, -1);
    var rel = parts[1].split(/ *= */)[1].slice(1, -1);
    obj[rel] = url;
    return obj;
  }, {});
};
/**
 * Strip content related fields from `header`.
 *
 * @param {Object} header
 * @return {Object} header
 * @api private
 */


exports.cleanHeader = function (header, changesOrigin) {
  delete header['content-type'];
  delete header['content-length'];
  delete header['transfer-encoding'];
  delete header.host; // secuirty

  if (changesOrigin) {
    delete header.authorization;
    delete header.cookie;
  }

  return header;
};
},{}],"afOI":[function(require,module,exports) {
"use strict";
/**
 * Module dependencies.
 */

var utils = require('./utils');
/**
 * Expose `ResponseBase`.
 */


module.exports = ResponseBase;
/**
 * Initialize a new `ResponseBase`.
 *
 * @api public
 */

function ResponseBase(obj) {
  if (obj) return mixin(obj);
}
/**
 * Mixin the prototype properties.
 *
 * @param {Object} obj
 * @return {Object}
 * @api private
 */


function mixin(obj) {
  for (var key in ResponseBase.prototype) {
    if (Object.prototype.hasOwnProperty.call(ResponseBase.prototype, key)) obj[key] = ResponseBase.prototype[key];
  }

  return obj;
}
/**
 * Get case-insensitive `field` value.
 *
 * @param {String} field
 * @return {String}
 * @api public
 */


ResponseBase.prototype.get = function (field) {
  return this.header[field.toLowerCase()];
};
/**
 * Set header related properties:
 *
 *   - `.type` the content type without params
 *
 * A response of "Content-Type: text/plain; charset=utf-8"
 * will provide you with a `.type` of "text/plain".
 *
 * @param {Object} header
 * @api private
 */


ResponseBase.prototype._setHeaderProperties = function (header) {
  // TODO: moar!
  // TODO: make this a util
  // content-type
  var ct = header['content-type'] || '';
  this.type = utils.type(ct); // params

  var params = utils.params(ct);

  for (var key in params) {
    if (Object.prototype.hasOwnProperty.call(params, key)) this[key] = params[key];
  }

  this.links = {}; // links

  try {
    if (header.link) {
      this.links = utils.parseLinks(header.link);
    }
  } catch (err) {// ignore
  }
};
/**
 * Set flags such as `.ok` based on `status`.
 *
 * For example a 2xx response will give you a `.ok` of __true__
 * whereas 5xx will be __false__ and `.error` will be __true__. The
 * `.clientError` and `.serverError` are also available to be more
 * specific, and `.statusType` is the class of error ranging from 1..5
 * sometimes useful for mapping respond colors etc.
 *
 * "sugar" properties are also defined for common cases. Currently providing:
 *
 *   - .noContent
 *   - .badRequest
 *   - .unauthorized
 *   - .notAcceptable
 *   - .notFound
 *
 * @param {Number} status
 * @api private
 */


ResponseBase.prototype._setStatusProperties = function (status) {
  var type = status / 100 | 0; // status / class

  this.statusCode = status;
  this.status = this.statusCode;
  this.statusType = type; // basics

  this.info = type === 1;
  this.ok = type === 2;
  this.redirect = type === 3;
  this.clientError = type === 4;
  this.serverError = type === 5;
  this.error = type === 4 || type === 5 ? this.toError() : false; // sugar

  this.created = status === 201;
  this.accepted = status === 202;
  this.noContent = status === 204;
  this.badRequest = status === 400;
  this.unauthorized = status === 401;
  this.notAcceptable = status === 406;
  this.forbidden = status === 403;
  this.notFound = status === 404;
  this.unprocessableEntity = status === 422;
};
},{"./utils":"4wfi"}],"zbFA":[function(require,module,exports) {
"use strict";

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance");
}

function _iterableToArray(iter) {
  if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) {
      arr2[i] = arr[i];
    }

    return arr2;
  }
}

function Agent() {
  this._defaults = [];
}

['use', 'on', 'once', 'set', 'query', 'type', 'accept', 'auth', 'withCredentials', 'sortQuery', 'retry', 'ok', 'redirects', 'timeout', 'buffer', 'serialize', 'parse', 'ca', 'key', 'pfx', 'cert'].forEach(function (fn) {
  // Default setting for all requests from this agent
  Agent.prototype[fn] = function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    this._defaults.push({
      fn: fn,
      args: args
    });

    return this;
  };
});

Agent.prototype._setDefaults = function (req) {
  this._defaults.forEach(function (def) {
    req[def.fn].apply(req, _toConsumableArray(def.args));
  });
};

module.exports = Agent;
},{}],"CC3B":[function(require,module,exports) {
"use strict";

function _typeof(obj) {
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}
/**
 * Root reference for iframes.
 */


var root;

if (typeof window !== 'undefined') {
  // Browser window
  root = window;
} else if (typeof self === 'undefined') {
  // Other environments
  console.warn('Using browser-only version of superagent in non-browser environment');
  root = void 0;
} else {
  // Web Worker
  root = self;
}

var Emitter = require('component-emitter');

var safeStringify = require('fast-safe-stringify');

var RequestBase = require('./request-base');

var isObject = require('./is-object');

var ResponseBase = require('./response-base');

var Agent = require('./agent-base');
/**
 * Noop.
 */


function noop() {}
/**
 * Expose `request`.
 */


module.exports = function (method, url) {
  // callback
  if (typeof url === 'function') {
    return new exports.Request('GET', method).end(url);
  } // url first


  if (arguments.length === 1) {
    return new exports.Request('GET', method);
  }

  return new exports.Request(method, url);
};

exports = module.exports;
var request = exports;
exports.Request = Request;
/**
 * Determine XHR.
 */

request.getXHR = function () {
  if (root.XMLHttpRequest && (!root.location || root.location.protocol !== 'file:' || !root.ActiveXObject)) {
    return new XMLHttpRequest();
  }

  try {
    return new ActiveXObject('Microsoft.XMLHTTP');
  } catch (err) {}

  try {
    return new ActiveXObject('Msxml2.XMLHTTP.6.0');
  } catch (err) {}

  try {
    return new ActiveXObject('Msxml2.XMLHTTP.3.0');
  } catch (err) {}

  try {
    return new ActiveXObject('Msxml2.XMLHTTP');
  } catch (err) {}

  throw new Error('Browser-only version of superagent could not find XHR');
};
/**
 * Removes leading and trailing whitespace, added to support IE.
 *
 * @param {String} s
 * @return {String}
 * @api private
 */


var trim = ''.trim ? function (s) {
  return s.trim();
} : function (s) {
  return s.replace(/(^\s*|\s*$)/g, '');
};
/**
 * Serialize the given `obj`.
 *
 * @param {Object} obj
 * @return {String}
 * @api private
 */

function serialize(obj) {
  if (!isObject(obj)) return obj;
  var pairs = [];

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) pushEncodedKeyValuePair(pairs, key, obj[key]);
  }

  return pairs.join('&');
}
/**
 * Helps 'serialize' with serializing arrays.
 * Mutates the pairs array.
 *
 * @param {Array} pairs
 * @param {String} key
 * @param {Mixed} val
 */


function pushEncodedKeyValuePair(pairs, key, val) {
  if (val === undefined) return;

  if (val === null) {
    pairs.push(encodeURIComponent(key));
    return;
  }

  if (Array.isArray(val)) {
    val.forEach(function (v) {
      pushEncodedKeyValuePair(pairs, key, v);
    });
  } else if (isObject(val)) {
    for (var subkey in val) {
      if (Object.prototype.hasOwnProperty.call(val, subkey)) pushEncodedKeyValuePair(pairs, "".concat(key, "[").concat(subkey, "]"), val[subkey]);
    }
  } else {
    pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(val));
  }
}
/**
 * Expose serialization method.
 */


request.serializeObject = serialize;
/**
 * Parse the given x-www-form-urlencoded `str`.
 *
 * @param {String} str
 * @return {Object}
 * @api private
 */

function parseString(str) {
  var obj = {};
  var pairs = str.split('&');
  var pair;
  var pos;

  for (var i = 0, len = pairs.length; i < len; ++i) {
    pair = pairs[i];
    pos = pair.indexOf('=');

    if (pos === -1) {
      obj[decodeURIComponent(pair)] = '';
    } else {
      obj[decodeURIComponent(pair.slice(0, pos))] = decodeURIComponent(pair.slice(pos + 1));
    }
  }

  return obj;
}
/**
 * Expose parser.
 */


request.parseString = parseString;
/**
 * Default MIME type map.
 *
 *     superagent.types.xml = 'application/xml';
 *
 */

request.types = {
  html: 'text/html',
  json: 'application/json',
  xml: 'text/xml',
  urlencoded: 'application/x-www-form-urlencoded',
  form: 'application/x-www-form-urlencoded',
  'form-data': 'application/x-www-form-urlencoded'
};
/**
 * Default serialization map.
 *
 *     superagent.serialize['application/xml'] = function(obj){
 *       return 'generated xml here';
 *     };
 *
 */

request.serialize = {
  'application/x-www-form-urlencoded': serialize,
  'application/json': safeStringify
};
/**
 * Default parsers.
 *
 *     superagent.parse['application/xml'] = function(str){
 *       return { object parsed from str };
 *     };
 *
 */

request.parse = {
  'application/x-www-form-urlencoded': parseString,
  'application/json': JSON.parse
};
/**
 * Parse the given header `str` into
 * an object containing the mapped fields.
 *
 * @param {String} str
 * @return {Object}
 * @api private
 */

function parseHeader(str) {
  var lines = str.split(/\r?\n/);
  var fields = {};
  var index;
  var line;
  var field;
  var val;

  for (var i = 0, len = lines.length; i < len; ++i) {
    line = lines[i];
    index = line.indexOf(':');

    if (index === -1) {
      // could be empty line, just skip it
      continue;
    }

    field = line.slice(0, index).toLowerCase();
    val = trim(line.slice(index + 1));
    fields[field] = val;
  }

  return fields;
}
/**
 * Check if `mime` is json or has +json structured syntax suffix.
 *
 * @param {String} mime
 * @return {Boolean}
 * @api private
 */


function isJSON(mime) {
  // should match /json or +json
  // but not /json-seq
  return /[/+]json($|[^-\w])/.test(mime);
}
/**
 * Initialize a new `Response` with the given `xhr`.
 *
 *  - set flags (.ok, .error, etc)
 *  - parse header
 *
 * Examples:
 *
 *  Aliasing `superagent` as `request` is nice:
 *
 *      request = superagent;
 *
 *  We can use the promise-like API, or pass callbacks:
 *
 *      request.get('/').end(function(res){});
 *      request.get('/', function(res){});
 *
 *  Sending data can be chained:
 *
 *      request
 *        .post('/user')
 *        .send({ name: 'tj' })
 *        .end(function(res){});
 *
 *  Or passed to `.send()`:
 *
 *      request
 *        .post('/user')
 *        .send({ name: 'tj' }, function(res){});
 *
 *  Or passed to `.post()`:
 *
 *      request
 *        .post('/user', { name: 'tj' })
 *        .end(function(res){});
 *
 * Or further reduced to a single call for simple cases:
 *
 *      request
 *        .post('/user', { name: 'tj' }, function(res){});
 *
 * @param {XMLHTTPRequest} xhr
 * @param {Object} options
 * @api private
 */


function Response(req) {
  this.req = req;
  this.xhr = this.req.xhr; // responseText is accessible only if responseType is '' or 'text' and on older browsers

  this.text = this.req.method !== 'HEAD' && (this.xhr.responseType === '' || this.xhr.responseType === 'text') || typeof this.xhr.responseType === 'undefined' ? this.xhr.responseText : null;
  this.statusText = this.req.xhr.statusText;
  var status = this.xhr.status; // handle IE9 bug: http://stackoverflow.com/questions/10046972/msie-returns-status-code-of-1223-for-ajax-request

  if (status === 1223) {
    status = 204;
  }

  this._setStatusProperties(status);

  this.headers = parseHeader(this.xhr.getAllResponseHeaders());
  this.header = this.headers; // getAllResponseHeaders sometimes falsely returns "" for CORS requests, but
  // getResponseHeader still works. so we get content-type even if getting
  // other headers fails.

  this.header['content-type'] = this.xhr.getResponseHeader('content-type');

  this._setHeaderProperties(this.header);

  if (this.text === null && req._responseType) {
    this.body = this.xhr.response;
  } else {
    this.body = this.req.method === 'HEAD' ? null : this._parseBody(this.text ? this.text : this.xhr.response);
  }
} // eslint-disable-next-line new-cap


ResponseBase(Response.prototype);
/**
 * Parse the given body `str`.
 *
 * Used for auto-parsing of bodies. Parsers
 * are defined on the `superagent.parse` object.
 *
 * @param {String} str
 * @return {Mixed}
 * @api private
 */

Response.prototype._parseBody = function (str) {
  var parse = request.parse[this.type];

  if (this.req._parser) {
    return this.req._parser(this, str);
  }

  if (!parse && isJSON(this.type)) {
    parse = request.parse['application/json'];
  }

  return parse && str && (str.length > 0 || str instanceof Object) ? parse(str) : null;
};
/**
 * Return an `Error` representative of this response.
 *
 * @return {Error}
 * @api public
 */


Response.prototype.toError = function () {
  var req = this.req;
  var method = req.method;
  var url = req.url;
  var msg = "cannot ".concat(method, " ").concat(url, " (").concat(this.status, ")");
  var err = new Error(msg);
  err.status = this.status;
  err.method = method;
  err.url = url;
  return err;
};
/**
 * Expose `Response`.
 */


request.Response = Response;
/**
 * Initialize a new `Request` with the given `method` and `url`.
 *
 * @param {String} method
 * @param {String} url
 * @api public
 */

function Request(method, url) {
  var self = this;
  this._query = this._query || [];
  this.method = method;
  this.url = url;
  this.header = {}; // preserves header name case

  this._header = {}; // coerces header names to lowercase

  this.on('end', function () {
    var err = null;
    var res = null;

    try {
      res = new Response(self);
    } catch (err2) {
      err = new Error('Parser is unable to parse the response');
      err.parse = true;
      err.original = err2; // issue #675: return the raw response if the response parsing fails

      if (self.xhr) {
        // ie9 doesn't have 'response' property
        err.rawResponse = typeof self.xhr.responseType === 'undefined' ? self.xhr.responseText : self.xhr.response; // issue #876: return the http status code if the response parsing fails

        err.status = self.xhr.status ? self.xhr.status : null;
        err.statusCode = err.status; // backwards-compat only
      } else {
        err.rawResponse = null;
        err.status = null;
      }

      return self.callback(err);
    }

    self.emit('response', res);
    var new_err;

    try {
      if (!self._isResponseOK(res)) {
        new_err = new Error(res.statusText || 'Unsuccessful HTTP response');
      }
    } catch (err2) {
      new_err = err2; // ok() callback can throw
    } // #1000 don't catch errors from the callback to avoid double calling it


    if (new_err) {
      new_err.original = err;
      new_err.response = res;
      new_err.status = res.status;
      self.callback(new_err, res);
    } else {
      self.callback(null, res);
    }
  });
}
/**
 * Mixin `Emitter` and `RequestBase`.
 */
// eslint-disable-next-line new-cap


Emitter(Request.prototype); // eslint-disable-next-line new-cap

RequestBase(Request.prototype);
/**
 * Set Content-Type to `type`, mapping values from `request.types`.
 *
 * Examples:
 *
 *      superagent.types.xml = 'application/xml';
 *
 *      request.post('/')
 *        .type('xml')
 *        .send(xmlstring)
 *        .end(callback);
 *
 *      request.post('/')
 *        .type('application/xml')
 *        .send(xmlstring)
 *        .end(callback);
 *
 * @param {String} type
 * @return {Request} for chaining
 * @api public
 */

Request.prototype.type = function (type) {
  this.set('Content-Type', request.types[type] || type);
  return this;
};
/**
 * Set Accept to `type`, mapping values from `request.types`.
 *
 * Examples:
 *
 *      superagent.types.json = 'application/json';
 *
 *      request.get('/agent')
 *        .accept('json')
 *        .end(callback);
 *
 *      request.get('/agent')
 *        .accept('application/json')
 *        .end(callback);
 *
 * @param {String} accept
 * @return {Request} for chaining
 * @api public
 */


Request.prototype.accept = function (type) {
  this.set('Accept', request.types[type] || type);
  return this;
};
/**
 * Set Authorization field value with `user` and `pass`.
 *
 * @param {String} user
 * @param {String} [pass] optional in case of using 'bearer' as type
 * @param {Object} options with 'type' property 'auto', 'basic' or 'bearer' (default 'basic')
 * @return {Request} for chaining
 * @api public
 */


Request.prototype.auth = function (user, pass, options) {
  if (arguments.length === 1) pass = '';

  if (_typeof(pass) === 'object' && pass !== null) {
    // pass is optional and can be replaced with options
    options = pass;
    pass = '';
  }

  if (!options) {
    options = {
      type: typeof btoa === 'function' ? 'basic' : 'auto'
    };
  }

  var encoder = function encoder(string) {
    if (typeof btoa === 'function') {
      return btoa(string);
    }

    throw new Error('Cannot use basic auth, btoa is not a function');
  };

  return this._auth(user, pass, options, encoder);
};
/**
 * Add query-string `val`.
 *
 * Examples:
 *
 *   request.get('/shoes')
 *     .query('size=10')
 *     .query({ color: 'blue' })
 *
 * @param {Object|String} val
 * @return {Request} for chaining
 * @api public
 */


Request.prototype.query = function (val) {
  if (typeof val !== 'string') val = serialize(val);
  if (val) this._query.push(val);
  return this;
};
/**
 * Queue the given `file` as an attachment to the specified `field`,
 * with optional `options` (or filename).
 *
 * ``` js
 * request.post('/upload')
 *   .attach('content', new Blob(['<a id="a"><b id="b">hey!</b></a>'], { type: "text/html"}))
 *   .end(callback);
 * ```
 *
 * @param {String} field
 * @param {Blob|File} file
 * @param {String|Object} options
 * @return {Request} for chaining
 * @api public
 */


Request.prototype.attach = function (field, file, options) {
  if (file) {
    if (this._data) {
      throw new Error("superagent can't mix .send() and .attach()");
    }

    this._getFormData().append(field, file, options || file.name);
  }

  return this;
};

Request.prototype._getFormData = function () {
  if (!this._formData) {
    this._formData = new root.FormData();
  }

  return this._formData;
};
/**
 * Invoke the callback with `err` and `res`
 * and handle arity check.
 *
 * @param {Error} err
 * @param {Response} res
 * @api private
 */


Request.prototype.callback = function (err, res) {
  if (this._shouldRetry(err, res)) {
    return this._retry();
  }

  var fn = this._callback;
  this.clearTimeout();

  if (err) {
    if (this._maxRetries) err.retries = this._retries - 1;
    this.emit('error', err);
  }

  fn(err, res);
};
/**
 * Invoke callback with x-domain error.
 *
 * @api private
 */


Request.prototype.crossDomainError = function () {
  var err = new Error('Request has been terminated\nPossible causes: the network is offline, Origin is not allowed by Access-Control-Allow-Origin, the page is being unloaded, etc.');
  err.crossDomain = true;
  err.status = this.status;
  err.method = this.method;
  err.url = this.url;
  this.callback(err);
}; // This only warns, because the request is still likely to work


Request.prototype.agent = function () {
  console.warn('This is not supported in browser version of superagent');
  return this;
};

Request.prototype.buffer = Request.prototype.ca;
Request.prototype.ca = Request.prototype.agent; // This throws, because it can't send/receive data as expected

Request.prototype.write = function () {
  throw new Error('Streaming is not supported in browser version of superagent');
};

Request.prototype.pipe = Request.prototype.write;
/**
 * Check if `obj` is a host object,
 * we don't want to serialize these :)
 *
 * @param {Object} obj host object
 * @return {Boolean} is a host object
 * @api private
 */

Request.prototype._isHost = function (obj) {
  // Native objects stringify to [object File], [object Blob], [object FormData], etc.
  return obj && _typeof(obj) === 'object' && !Array.isArray(obj) && Object.prototype.toString.call(obj) !== '[object Object]';
};
/**
 * Initiate request, invoking callback `fn(res)`
 * with an instanceof `Response`.
 *
 * @param {Function} fn
 * @return {Request} for chaining
 * @api public
 */


Request.prototype.end = function (fn) {
  if (this._endCalled) {
    console.warn('Warning: .end() was called twice. This is not supported in superagent');
  }

  this._endCalled = true; // store callback

  this._callback = fn || noop; // querystring

  this._finalizeQueryString();

  this._end();
};

Request.prototype._setUploadTimeout = function () {
  var self = this; // upload timeout it's wokrs only if deadline timeout is off

  if (this._uploadTimeout && !this._uploadTimeoutTimer) {
    this._uploadTimeoutTimer = setTimeout(function () {
      self._timeoutError('Upload timeout of ', self._uploadTimeout, 'ETIMEDOUT');
    }, this._uploadTimeout);
  }
}; // eslint-disable-next-line complexity


Request.prototype._end = function () {
  if (this._aborted) return this.callback(new Error('The request has been aborted even before .end() was called'));
  var self = this;
  this.xhr = request.getXHR();
  var xhr = this.xhr;
  var data = this._formData || this._data;

  this._setTimeouts(); // state change


  xhr.onreadystatechange = function () {
    var readyState = xhr.readyState;

    if (readyState >= 2 && self._responseTimeoutTimer) {
      clearTimeout(self._responseTimeoutTimer);
    }

    if (readyState !== 4) {
      return;
    } // In IE9, reads to any property (e.g. status) off of an aborted XHR will
    // result in the error "Could not complete the operation due to error c00c023f"


    var status;

    try {
      status = xhr.status;
    } catch (err) {
      status = 0;
    }

    if (!status) {
      if (self.timedout || self._aborted) return;
      return self.crossDomainError();
    }

    self.emit('end');
  }; // progress


  var handleProgress = function handleProgress(direction, e) {
    if (e.total > 0) {
      e.percent = e.loaded / e.total * 100;

      if (e.percent === 100) {
        clearTimeout(self._uploadTimeoutTimer);
      }
    }

    e.direction = direction;
    self.emit('progress', e);
  };

  if (this.hasListeners('progress')) {
    try {
      xhr.addEventListener('progress', handleProgress.bind(null, 'download'));

      if (xhr.upload) {
        xhr.upload.addEventListener('progress', handleProgress.bind(null, 'upload'));
      }
    } catch (err) {// Accessing xhr.upload fails in IE from a web worker, so just pretend it doesn't exist.
      // Reported here:
      // https://connect.microsoft.com/IE/feedback/details/837245/xmlhttprequest-upload-throws-invalid-argument-when-used-from-web-worker-context
    }
  }

  if (xhr.upload) {
    this._setUploadTimeout();
  } // initiate request


  try {
    if (this.username && this.password) {
      xhr.open(this.method, this.url, true, this.username, this.password);
    } else {
      xhr.open(this.method, this.url, true);
    }
  } catch (err) {
    // see #1149
    return this.callback(err);
  } // CORS


  if (this._withCredentials) xhr.withCredentials = true; // body

  if (!this._formData && this.method !== 'GET' && this.method !== 'HEAD' && typeof data !== 'string' && !this._isHost(data)) {
    // serialize stuff
    var contentType = this._header['content-type'];

    var _serialize = this._serializer || request.serialize[contentType ? contentType.split(';')[0] : ''];

    if (!_serialize && isJSON(contentType)) {
      _serialize = request.serialize['application/json'];
    }

    if (_serialize) data = _serialize(data);
  } // set header fields


  for (var field in this.header) {
    if (this.header[field] === null) continue;
    if (Object.prototype.hasOwnProperty.call(this.header, field)) xhr.setRequestHeader(field, this.header[field]);
  }

  if (this._responseType) {
    xhr.responseType = this._responseType;
  } // send stuff


  this.emit('request', this); // IE11 xhr.send(undefined) sends 'undefined' string as POST payload (instead of nothing)
  // We need null here if data is undefined

  xhr.send(typeof data === 'undefined' ? null : data);
};

request.agent = function () {
  return new Agent();
};

['GET', 'POST', 'OPTIONS', 'PATCH', 'PUT', 'DELETE'].forEach(function (method) {
  Agent.prototype[method.toLowerCase()] = function (url, fn) {
    var req = new request.Request(method, url);

    this._setDefaults(req);

    if (fn) {
      req.end(fn);
    }

    return req;
  };
});
Agent.prototype.del = Agent.prototype.delete;
/**
 * GET `url` with optional callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed|Function} [data] or fn
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */

request.get = function (url, data, fn) {
  var req = request('GET', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.query(data);
  if (fn) req.end(fn);
  return req;
};
/**
 * HEAD `url` with optional callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed|Function} [data] or fn
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */


request.head = function (url, data, fn) {
  var req = request('HEAD', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.query(data);
  if (fn) req.end(fn);
  return req;
};
/**
 * OPTIONS query to `url` with optional callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed|Function} [data] or fn
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */


request.options = function (url, data, fn) {
  var req = request('OPTIONS', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.send(data);
  if (fn) req.end(fn);
  return req;
};
/**
 * DELETE `url` with optional `data` and callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed} [data]
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */


function del(url, data, fn) {
  var req = request('DELETE', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.send(data);
  if (fn) req.end(fn);
  return req;
}

request.del = del;
request.delete = del;
/**
 * PATCH `url` with optional `data` and callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed} [data]
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */

request.patch = function (url, data, fn) {
  var req = request('PATCH', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.send(data);
  if (fn) req.end(fn);
  return req;
};
/**
 * POST `url` with optional `data` and callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed} [data]
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */


request.post = function (url, data, fn) {
  var req = request('POST', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.send(data);
  if (fn) req.end(fn);
  return req;
};
/**
 * PUT `url` with optional `data` and callback `fn(res)`.
 *
 * @param {String} url
 * @param {Mixed|Function} [data] or fn
 * @param {Function} [fn]
 * @return {Request}
 * @api public
 */


request.put = function (url, data, fn) {
  var req = request('PUT', url);

  if (typeof data === 'function') {
    fn = data;
    data = null;
  }

  if (data) req.send(data);
  if (fn) req.end(fn);
  return req;
};
},{"component-emitter":"PHwb","fast-safe-stringify":"L4M6","./request-base":"zs9O","./is-object":"ymYf","./response-base":"afOI","./agent-base":"zbFA"}],"3HZv":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = {
  ip: '72.228.10.129',
  hostname: 'cpe-72-228-10-129.nycap.res.rr.com',
  type: 'ipv4',
  continent_code: 'NA',
  continent_name: 'North America',
  country_code: 'US',
  country_name: 'United States',
  region_code: 'MA',
  region_name: 'Massachusetts',
  city: 'Great Barrington',
  zip: '01230',
  latitude: 42.1617,
  longitude: -73.3277,
  location: {
    geoname_id: 4938157,
    capital: 'Washington D.C.',
    languages: [{
      code: 'en',
      name: 'English',
      native: 'English'
    }],
    country_flag: 'http://assets.ipstack.com/flags/us.svg',
    country_flag_emoji: '🇺🇸',
    country_flag_emoji_unicode: 'U+1F1FA U+1F1F8',
    calling_code: '1',
    is_eu: false
  },
  time_zone: {
    id: 'America/New_York',
    current_time: '2018-04-17T15:29:13-04:00',
    gmt_offset: -14400,
    code: 'EDT',
    is_daylight_saving: true
  },
  currency: {
    code: 'USD',
    name: 'US Dollar',
    plural: 'US dollars',
    symbol: '$',
    symbol_native: '$'
  },
  connection: {
    asn: 11351,
    isp: 'Time Warner Cable Internet LLC'
  },
  security: {
    is_proxy: false,
    proxy_type: null,
    is_crawler: false,
    crawler_name: null,
    crawler_type: null,
    is_tor: false,
    threat_level: 'low',
    threat_types: null
  }
};
exports.default = _default;
},{}],"NSOq":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _superagent = _interopRequireDefault(require("superagent"));

var _locateTest = _interopRequireDefault(require("./locate-test"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* USAGE:
locate(key, (err, result) => {
  ...
})
*/
var debug = false;
var MAX_TIME = 4000;
var key = null;

function getIP() {
  if (debug) return Promise.resolve(_locateTest.default);
  var url = 'https://api.ipify.org?format=json';
  return new Promise(function (resolve, reject) {
    _superagent.default.get(url).end(function (err, res) {
      if (err) reject(err);else if (res && res.status >= 200 && res.status < 400) resolve(JSON.parse(res.text));else reject(err);
    });
  });
}

function getGeocode(_ref) {
  var ip = _ref.ip;
  if (debug) return Promise.resolve(_locateTest.default);
  var url = "https://api.ipstack.com/".concat(ip, "?access_key=").concat(key);
  return new Promise(function (resolve, reject) {
    _superagent.default.get(url).end(function (err, res) {
      if (err) reject(err);else if (res && res.status >= 200 && res.status < 400) {
        var j = JSON.parse(res.text);
        if (j.error) reject(j.error);else resolve(j);
      } else reject(err);
    });
  });
}
/**
 * Get users approx. location according to IP address
 * @param {function} cb callback funtion
 */


function init(k, cb) {
  if (k) {
    key = k;
    var timeout = setTimeout(function () {
      return cb('timeout');
    }, MAX_TIME);
    getIP().then(getGeocode).then(function (response) {
      clearTimeout(timeout);
      cb(null, response);
    }).catch(function (err) {
      return cb(err);
    });
  } else cb('error: must pass ipstack key');
}

var _default = init;
exports.default = _default;
},{"superagent":"CC3B","./locate-test":"3HZv"}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _exportedDogs = _interopRequireDefault(require("./exported-dogs"));

var _footer = _interopRequireDefault(require("./footer"));

var _usStateData = _interopRequireDefault(require("./utils/us-state-data"));

var _northernMovement = _interopRequireDefault(require("./northern-movement"));

var _tileMovement = _interopRequireDefault(require("./tile-movement"));

var _countries = _interopRequireDefault(require("./countries"));

var _loadData = _interopRequireDefault(require("./load-data"));

var _locate = _interopRequireDefault(require("./utils/locate"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var $body = d3.select('body');
var previousWidth = 0;
var $dropdown = d3.selectAll('.stateSelect');
var readerState = 'New York';
var defaultLocation = {
  country_code: 'US',
  country_name: 'United States',
  region_code: 'NY',
  region_name: 'New York',
  city: 'New York',
  zip_code: '10001',
  time_zone: 'America/New_York',
  latitude: 40,
  longitude: -72
};
var importExport = null;
var filteredDD = null;
var allDD = null;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();

    _tileMovement.default.resize();
  }
}

function findReaderState() {
  return new Promise(function (resolve, reject) {
    var key = 'fd4d87f605681c0959c16d9164ab6a4a';
    (0, _locate.default)(key, function (err, result) {
      readerState = err || result.country_code !== 'US' ? defaultLocation.region_name : result.region_name;
      resolve(readerState);
    });
  });
}

function updateLocation(condition) {
  // only update the text/image if it is the upper dropdown that's changed
  if (condition === 'all') _graphic.default.updateLocation(readerState); // everything else is always updated

  _exportedDogs.default.updateLocation(readerState);

  filteredDD.selectAll('option').property('selected', function (d) {
    return d === readerState;
  }); // allDD.selectAll('option').property('selected', d => d === readerState)
}

function setupStateDropdown() {
  var justStates = _usStateData.default.map(function (d) {
    return d.state;
  }).sort(function (a, b) {
    return d3.ascending(a, b);
  });

  $dropdown.selectAll('option').data(justStates).enter().append('option').attr('value', function (d) {
    return d;
  }).text(function (d) {
    return d;
  }).property('selected', function (d) {
    return d === readerState;
  });
  $dropdown.on('change', function change() {
    var dd = d3.select(this).attr('data-condition');
    readerState = this.value;
    updateLocation(dd);
  });
}

function setupStickyHeader() {
  var $header = $body.select('header');

  if ($header.classed('is-sticky')) {
    var $menu = $body.select('.header__menu');
    var $toggle = $body.select('.header__toggle');
    $toggle.on('click', function () {
      var visible = $menu.classed('is-visible');
      $menu.classed('is-visible', !visible);
      $toggle.classed('is-visible', !visible);
    });
  }
}

function cleanData(arr) {
  return arr.map(function (d, i) {
    return _objectSpread({}, d, {
      imported: +d.imported,
      exported: +d.exported,
      number: i
    });
  });
}

function setup() {
  // add mobile class to body tag
  $body.classed('is-mobile', _isMobile.default.any()); // setup resize event

  window.addEventListener('resize', (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader();
  findReaderState().then(function () {
    // kick off graphic code
    setupStateDropdown();

    _graphic.default.init(readerState);

    _exportedDogs.default.init(readerState);

    _tileMovement.default.init();

    _countries.default.init();
  }); // load footer stories

  _footer.default.init();
}

function init() {
  _loadData.default.loadCSV('importExport.csv').then(function (result) {
    importExport = cleanData(result);
    setup();
  }).catch(console.error);
}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./graphic":"TAPd","./exported-dogs":"sOMx","./footer":"v9Q8","./utils/us-state-data":"osrT","./northern-movement":"dOkl","./tile-movement":"KRMc","./countries":"countries.js","./load-data":"xZJw","./utils/locate":"NSOq"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map